package com.example.ownercafeoda.OrderList;

public interface getCafeInfo {
    String getCafeId();
}
