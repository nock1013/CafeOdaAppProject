package com.example.ownercafeoda;

import android.os.Bundle;

// Menu Insert Delete 용 interface //
public interface OnItemClick {
    void onClick (String value, Bundle data);
}
