package com.example.cafeoda.Mainpage;

public interface ItemClick {
    void onClick(String val,int cafeid);
}
