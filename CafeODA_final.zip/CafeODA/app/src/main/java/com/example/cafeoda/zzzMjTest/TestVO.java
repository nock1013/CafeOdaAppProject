package com.example.cafeoda.zzzMjTest;

public class TestVO {

     int testnum;
     String teststr;

    public TestVO(int testnum, String teststr) {
        this.testnum = testnum;
        this.teststr = teststr;
    }

    public int getTestnum() {
        return testnum;
    }

    public String getTeststr() {
        return teststr;
    }
}
