package cafe.oda.getStationCount;

public class stationDTO {
    String datamonth;
    String line;
    String stationname;
    int t0405on;
    int t0405off;
    int t0506on;
    int t0506off;
    int t0607on;
    int t0607off;
    int t0708on;
    int t0708off;
    int t0809on;
    int t0809off;
    int t0910on;
    int t0910off;
    int t1011on;
    int t1011off;
    int t1112on;
    int t1112off;
    int t1213on;
    int t1213off;
    int t1314on;
    int t1314off;
    int t1415on;
    int t1415off;
    int t1516on;
    int t1516off;
    int t1617on;
    int t1617off;
    int t1718on;
    int t1718off;
    int t1819on;
    int t1819off;
    int t1920on;
    int t1920off;
    int t2021on;
    int t2021off;
    int t2122on;
    int t2122off;
    int t2223on;
    int t2223off;
    int t2324on;
    int t2324off;
    int t0001on;
    int t0001off;
    int t0102on;
    int t0102off;
    int t0203on;
    int t0203off;
    int t0304on;
    int t0304off;

    public stationDTO(String datamonth, String line, String stationname, int t0405on, int t0405off, int t0506on, int t0506off, int t0607on, int t0607off, int t0708on, int t0708off, int t0809on, int t0809off, int t0910on, int t0910off, int t1011on, int t1011off, int t1112on, int t1112off, int t1213on, int t1213off, int t1314on, int t1314off, int t1415on, int t1415off, int t1516on, int t1516off, int t1617on, int t1617off, int t1718on, int t1718off, int t1819on, int t1819off, int t1920on, int t1920off, int t2021on, int t2021off, int t2122on, int t2122off, int t2223on, int t2223off, int t2324on, int t2324off, int t0001on, int t0001off, int t0102on, int t0102off, int t0203on, int t0203off, int t0304on, int t0304off) {
        this.datamonth = datamonth;
        this.line = line;
        this.stationname = stationname;
        this.t0405on = t0405on;
        this.t0405off = t0405off;
        this.t0506on = t0506on;
        this.t0506off = t0506off;
        this.t0607on = t0607on;
        this.t0607off = t0607off;
        this.t0708on = t0708on;
        this.t0708off = t0708off;
        this.t0809on = t0809on;
        this.t0809off = t0809off;
        this.t0910on = t0910on;
        this.t0910off = t0910off;
        this.t1011on = t1011on;
        this.t1011off = t1011off;
        this.t1112on = t1112on;
        this.t1112off = t1112off;
        this.t1213on = t1213on;
        this.t1213off = t1213off;
        this.t1314on = t1314on;
        this.t1314off = t1314off;
        this.t1415on = t1415on;
        this.t1415off = t1415off;
        this.t1516on = t1516on;
        this.t1516off = t1516off;
        this.t1617on = t1617on;
        this.t1617off = t1617off;
        this.t1718on = t1718on;
        this.t1718off = t1718off;
        this.t1819on = t1819on;
        this.t1819off = t1819off;
        this.t1920on = t1920on;
        this.t1920off = t1920off;
        this.t2021on = t2021on;
        this.t2021off = t2021off;
        this.t2122on = t2122on;
        this.t2122off = t2122off;
        this.t2223on = t2223on;
        this.t2223off = t2223off;
        this.t2324on = t2324on;
        this.t2324off = t2324off;
        this.t0001on = t0001on;
        this.t0001off = t0001off;
        this.t0102on = t0102on;
        this.t0102off = t0102off;
        this.t0203on = t0203on;
        this.t0203off = t0203off;
        this.t0304on = t0304on;
        this.t0304off = t0304off;
    }

    public stationDTO() {
    }

    @Override
    public String toString() {
        return "stationDTO{" +
                "datamonth='" + datamonth + '\'' +
                ", line='" + line + '\'' +
                ", stationname='" + stationname + '\'' +
                ", t0405on=" + t0405on +
                ", t0405off=" + t0405off +
                ", t0506on=" + t0506on +
                ", t0506off=" + t0506off +
                ", t0607on=" + t0607on +
                ", t0607off=" + t0607off +
                ", t0708on=" + t0708on +
                ", t0708off=" + t0708off +
                ", t0809on=" + t0809on +
                ", t0809off=" + t0809off +
                ", t0910on=" + t0910on +
                ", t0910off=" + t0910off +
                ", t1011on=" + t1011on +
                ", t1011off=" + t1011off +
                ", t1112on=" + t1112on +
                ", t1112off=" + t1112off +
                ", t1213on=" + t1213on +
                ", t1213off=" + t1213off +
                ", t1314on=" + t1314on +
                ", t1314off=" + t1314off +
                ", t1415on=" + t1415on +
                ", t1415off=" + t1415off +
                ", t1516on=" + t1516on +
                ", t1516off=" + t1516off +
                ", t1617on=" + t1617on +
                ", t1617off=" + t1617off +
                ", t1718on=" + t1718on +
                ", t1718off=" + t1718off +
                ", t1819on=" + t1819on +
                ", t1819off=" + t1819off +
                ", t1920on=" + t1920on +
                ", t1920off=" + t1920off +
                ", t2021on=" + t2021on +
                ", t2021off=" + t2021off +
                ", t2122on=" + t2122on +
                ", t2122off=" + t2122off +
                ", t2223on=" + t2223on +
                ", t2223off=" + t2223off +
                ", t2324on=" + t2324on +
                ", t2324off=" + t2324off +
                ", t0001on=" + t0001on +
                ", t0001off=" + t0001off +
                ", t0102on=" + t0102on +
                ", t0102off=" + t0102off +
                ", t0203on=" + t0203on +
                ", t0203off=" + t0203off +
                ", t0304on=" + t0304on +
                ", t0304off=" + t0304off +
                '}';
    }

    public String getDatamonth() {
        return datamonth;
    }

    public void setDatamonth(String datamonth) {
        this.datamonth = datamonth;
    }

    public String getLine() {
        return line;
    }

    public void setLine(String line) {
        this.line = line;
    }

    public String getStationname() {
        return stationname;
    }

    public void setStationname(String stationname) {
        this.stationname = stationname;
    }

    public int getT0405on() {
        return t0405on;
    }

    public void setT0405on(int t0405on) {
        this.t0405on = t0405on;
    }

    public int getT0405off() {
        return t0405off;
    }

    public void setT0405off(int t0405off) {
        this.t0405off = t0405off;
    }

    public int getT0506on() {
        return t0506on;
    }

    public void setT0506on(int t0506on) {
        this.t0506on = t0506on;
    }

    public int getT0506off() {
        return t0506off;
    }

    public void setT0506off(int t0506off) {
        this.t0506off = t0506off;
    }

    public int getT0607on() {
        return t0607on;
    }

    public void setT0607on(int t0607on) {
        this.t0607on = t0607on;
    }

    public int getT0607off() {
        return t0607off;
    }

    public void setT0607off(int t0607off) {
        this.t0607off = t0607off;
    }

    public int getT0708on() {
        return t0708on;
    }

    public void setT0708on(int t0708on) {
        this.t0708on = t0708on;
    }

    public int getT0708off() {
        return t0708off;
    }

    public void setT0708off(int t0708off) {
        this.t0708off = t0708off;
    }

    public int getT0809on() {
        return t0809on;
    }

    public void setT0809on(int t0809on) {
        this.t0809on = t0809on;
    }

    public int getT0809off() {
        return t0809off;
    }

    public void setT0809off(int t0809off) {
        this.t0809off = t0809off;
    }

    public int getT0910on() {
        return t0910on;
    }

    public void setT0910on(int t0910on) {
        this.t0910on = t0910on;
    }

    public int getT0910off() {
        return t0910off;
    }

    public void setT0910off(int t0910off) {
        this.t0910off = t0910off;
    }

    public int getT1011on() {
        return t1011on;
    }

    public void setT1011on(int t1011on) {
        this.t1011on = t1011on;
    }

    public int getT1011off() {
        return t1011off;
    }

    public void setT1011off(int t1011off) {
        this.t1011off = t1011off;
    }

    public int getT1112on() {
        return t1112on;
    }

    public void setT1112on(int t1112on) {
        this.t1112on = t1112on;
    }

    public int getT1112off() {
        return t1112off;
    }

    public void setT1112off(int t1112off) {
        this.t1112off = t1112off;
    }

    public int getT1213on() {
        return t1213on;
    }

    public void setT1213on(int t1213on) {
        this.t1213on = t1213on;
    }

    public int getT1213off() {
        return t1213off;
    }

    public void setT1213off(int t1213off) {
        this.t1213off = t1213off;
    }

    public int getT1314on() {
        return t1314on;
    }

    public void setT1314on(int t1314on) {
        this.t1314on = t1314on;
    }

    public int getT1314off() {
        return t1314off;
    }

    public void setT1314off(int t1314off) {
        this.t1314off = t1314off;
    }

    public int getT1415on() {
        return t1415on;
    }

    public void setT1415on(int t1415on) {
        this.t1415on = t1415on;
    }

    public int getT1415off() {
        return t1415off;
    }

    public void setT1415off(int t1415off) {
        this.t1415off = t1415off;
    }

    public int getT1516on() {
        return t1516on;
    }

    public void setT1516on(int t1516on) {
        this.t1516on = t1516on;
    }

    public int getT1516off() {
        return t1516off;
    }

    public void setT1516off(int t1516off) {
        this.t1516off = t1516off;
    }

    public int getT1617on() {
        return t1617on;
    }

    public void setT1617on(int t1617on) {
        this.t1617on = t1617on;
    }

    public int getT1617off() {
        return t1617off;
    }

    public void setT1617off(int t1617off) {
        this.t1617off = t1617off;
    }

    public int getT1718on() {
        return t1718on;
    }

    public void setT1718on(int t1718on) {
        this.t1718on = t1718on;
    }

    public int getT1718off() {
        return t1718off;
    }

    public void setT1718off(int t1718off) {
        this.t1718off = t1718off;
    }

    public int getT1819on() {
        return t1819on;
    }

    public void setT1819on(int t1819on) {
        this.t1819on = t1819on;
    }

    public int getT1819off() {
        return t1819off;
    }

    public void setT1819off(int t1819off) {
        this.t1819off = t1819off;
    }

    public int getT1920on() {
        return t1920on;
    }

    public void setT1920on(int t1920on) {
        this.t1920on = t1920on;
    }

    public int getT1920off() {
        return t1920off;
    }

    public void setT1920off(int t1920off) {
        this.t1920off = t1920off;
    }

    public int getT2021on() {
        return t2021on;
    }

    public void setT2021on(int t2021on) {
        this.t2021on = t2021on;
    }

    public int getT2021off() {
        return t2021off;
    }

    public void setT2021off(int t2021off) {
        this.t2021off = t2021off;
    }

    public int getT2122on() {
        return t2122on;
    }

    public void setT2122on(int t2122on) {
        this.t2122on = t2122on;
    }

    public int getT2122off() {
        return t2122off;
    }

    public void setT2122off(int t2122off) {
        this.t2122off = t2122off;
    }

    public int getT2223on() {
        return t2223on;
    }

    public void setT2223on(int t2223on) {
        this.t2223on = t2223on;
    }

    public int getT2223off() {
        return t2223off;
    }

    public void setT2223off(int t2223off) {
        this.t2223off = t2223off;
    }

    public int getT2324on() {
        return t2324on;
    }

    public void setT2324on(int t2324on) {
        this.t2324on = t2324on;
    }

    public int getT2324off() {
        return t2324off;
    }

    public void setT2324off(int t2324off) {
        this.t2324off = t2324off;
    }

    public int getT0001on() {
        return t0001on;
    }

    public void setT0001on(int t0001on) {
        this.t0001on = t0001on;
    }

    public int getT0001off() {
        return t0001off;
    }

    public void setT0001off(int t0001off) {
        this.t0001off = t0001off;
    }

    public int getT0102on() {
        return t0102on;
    }

    public void setT0102on(int t0102on) {
        this.t0102on = t0102on;
    }

    public int getT0102off() {
        return t0102off;
    }

    public void setT0102off(int t0102off) {
        this.t0102off = t0102off;
    }

    public int getT0203on() {
        return t0203on;
    }

    public void setT0203on(int t0203on) {
        this.t0203on = t0203on;
    }

    public int getT0203off() {
        return t0203off;
    }

    public void setT0203off(int t0203off) {
        this.t0203off = t0203off;
    }

    public int getT0304on() {
        return t0304on;
    }

    public void setT0304on(int t0304on) {
        this.t0304on = t0304on;
    }

    public int getT0304off() {
        return t0304off;
    }

    public void setT0304off(int t0304off) {
        this.t0304off = t0304off;
    }
}
