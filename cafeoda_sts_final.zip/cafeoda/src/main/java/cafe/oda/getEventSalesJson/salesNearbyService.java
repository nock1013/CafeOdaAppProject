package cafe.oda.getEventSalesJson;

import java.util.List;

public interface salesNearbyService {
	public List<salesNearbyDTO> select(String road);

}
