package cafe.oda.getEventSalesJson;

import java.util.List;

public interface salesNearbyDAO {
	public List<salesNearbyDTO> select(String road);

}
